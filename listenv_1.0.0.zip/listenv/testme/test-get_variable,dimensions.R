library("listenv")

ovars <- ls(envir = globalenv())
oopts <- options(warn = 1)

message("* get_variable() - multi-dimensional list environments ...")

message(" - two dimensions")
x <- listenv()
length(x) <- 6
dim(x) <- c(2, 3)

for (ii in seq_along(x)) {
  stopifnot(is.null(x[[ii]]))
  idx <- arrayInd(ii, .dim = dim(x))
  stopifnot(is.null(x[[idx[1], idx[2]]]))
  var_v <- get_variable(x, ii, create = FALSE)
  var_a <- get_variable(x, idx, create = FALSE)
  stopifnot(identical(var_a, var_v))
}

x[1:6] <- 1:6
for (ii in seq_along(x)) {
  stopifnot(identical(x[[ii]], ii))
  idx <- arrayInd(ii, .dim = dim(x))
  stopifnot(identical(x[[idx[1], idx[2]]], ii))

  var_v <- get_variable(x, ii)
  var_a <- get_variable(x, idx)
  stopifnot(identical(var_a, var_v))
}

message(" - three dimensions")
x <- as.listenv(1:24)
dim(x) <- c(2, 3, 4)
value <- x[1, 2, 3]
stopifnot(unlist(value) == 15)

name <- get_variable(x, c(1, 2, 3))
value2 <- get(name, envir = x, inherits = FALSE)
stopifnot(unlist(value2) == 15)

message("* get_variable() - multi-dimensional list environments ... DONE")

## Cleanup
options(oopts)
rm(list = setdiff(ls(envir = globalenv()), ovars), envir = globalenv())
