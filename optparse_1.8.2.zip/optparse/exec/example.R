#!/usr/bin/env Rscript
# Copyright 2010-2013 Trevor L Davis <trevor.l.davis@gmail.com>
# Copyright 2008 Allen Day
#
#  This file is free software: you may copy, redistribute and/or modify it
#  under the terms of the GNU General Public License as published by the
#  Free Software Foundation, either version 2 of the License, or (at your
#  option) any later version.
#
#  This file is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
suppressPackageStartupMessages(library("optparse"))
suppressPackageStartupMessages(library("stats"))

# specify our desired options in a list
# by default OptionParser will add an help option equivalent to
# make_option(c("-h", "--help"), action="store_true", default=FALSE,
#               help="Show this help message and exit")
parser <- OptionParser()
parser <- add_option(
	parser,
	c("-v", "--verbose"),
	action = "store_true",
	default = TRUE,
	help = "Print extra output [default %default]"
)
parser <- add_option(
	parser,
	c("-q", "--quietly"),
	action = "store_false",
	dest = "verbose",
	help = "Print little output"
)
parser <- add_option(
	parser,
	c("-c", "--count"),
	type = "integer",
	default = 5,
	help = "Number of random normals to generate [default %default]",
	metavar = "number"
)
parser <- add_option(
	parser,
	"--generator",
	default = "rnorm",
	help = "Function to generate random deviates [default \"%default\"]"
)
parser <- add_option(
	parser,
	"--mean",
	default = 0,
	help = "Mean if generator == \"rnorm\" [default %default]"
)
parser <- add_option(
	parser,
	"--sd",
	default = 1,
	metavar = "standard deviation",
	help = "Standard deviation if generator == \"rnorm\" [default %default]"
)

# get command line options, if help option encountered print help and exit,
# otherwise if options not found on command line then set defaults,
opt <- parse_args(parser)

# print some progress messages to stderr if "quietly" wasn't requested
if (opt$verbose) {
	write("writing some verbose output to standard error...\n", stderr())
}

# do some operations based on user input
if (opt$generator == "rnorm") {
	cat(paste(rnorm(opt$count, mean = opt$mean, sd = opt$sd), collapse = "\n"))
} else {
	cat(paste(do.call(opt$generator, list(opt$count)), collapse = "\n"))
}
cat("\n")
